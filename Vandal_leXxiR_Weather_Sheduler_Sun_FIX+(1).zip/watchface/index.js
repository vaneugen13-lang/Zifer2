﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let idle_background_bg = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''

        //dynamic modify end
		
		let weatherScreen = ''
		let weatherScreenOn = false
		let forecastWeatherIcons = []
		let tempHighText = []
		let tempLowText = []
		let weekDayText = []
		const ROOTPATH = "images/"
		let city_name_text = ''
		let pointRed = [];
		let pointBlue = [];
		let lineRed = [];
		let lineBlue = [];

		let tempH = [];
		let tempL = [];
		let closeWScreenTimeout = 25 * 1000;	// автозакрытие экрана погоды в сек
		let closeScreenTimeout = null;
		
		const curTime = hmSensor.createSensor(hmSensor.id.TIME);
		let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
		let weatherData = weather.getForecastWeather();
		let forecastData = weatherData.forecastData;

		function createGraphElements() {
		
			for (let i = 0; i < 6; i++) {
			  weekDayText[i] = weatherScreen.createWidget(hmUI.widget.TEXT, {
				  x: 102 + 2 + i * 46,
				  y: 302,
				  w: 30,
				  h: 22,
				  color: "0xFFF0E68C",
				  text: '',
				  text_size: 21,
				  text_style: hmUI.text_style.NONE,
				  align_h: hmUI.align.CENTER_H,
				  align_v: hmUI.align.CENTER_V,
				  show_level: hmUI.show_level.ONLY_NORMAL
				});

			  forecastWeatherIcons[i] = weatherScreen.createWidget(hmUI.widget.IMG, {
				x: 98 + i * 46,
				y: 78,
				w: 40,
				h: 40,
				show_level: hmUI.show_level.ONLY_NORMAL,
			  });
			  
			  pointRed[i] = weatherScreen.createWidget(hmUI.widget.FILL_RECT, {show_level: hmUI.show_level.ONLY_NORMAL});
			  pointBlue[i] = weatherScreen.createWidget(hmUI.widget.FILL_RECT, {show_level: hmUI.show_level.ONLY_NORMAL});
			  tempHighText[i] = weatherScreen.createWidget(hmUI.widget.TEXT, {show_level: hmUI.show_level.ONLY_NORMAL});
			  tempLowText[i] = weatherScreen.createWidget(hmUI.widget.TEXT, {show_level: hmUI.show_level.ONLY_NORMAL});
			}

			for (let i = 0; i < 5; i++) {
			  lineRed[i] = weatherScreen.createWidget(hmUI.widget.FILL_RECT, {show_level: hmUI.show_level.ONLY_NORMAL});
			  lineBlue[i] = weatherScreen.createWidget(hmUI.widget.FILL_RECT, {show_level: hmUI.show_level.ONLY_NORMAL});
			}

		}

		function drawWeatherGraph() {

			weather = hmSensor.createSensor(hmSensor.id.WEATHER);
			weatherData = weather.getForecastWeather();
			forecastData = weatherData.forecastData;
			let weekDay = curTime.week - 1;
			let shotDayNames = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];

			city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

			if (forecastData.count == 0) {
				for (let i = 0; i < 6; i++) {
					forecastWeatherIcons[i].setProperty(hmUI.prop.SRC, ROOTPATH + "weather/25.png");
				}
			} else {
				for (let i = 0; i < 6; i++) {
					tempH[i] = forecastData.data[i].high;
					tempL[i] = forecastData.data[i].low;
					let iconIndex = forecastData.data[i].index;
					weekDayText[i].setProperty(hmUI.prop.MORE, {
					  color: weekDay < 5 ? "0xFFF0E68C" : "0xFFFF0000",
					  text: shotDayNames[weekDay],
					});
					forecastWeatherIcons[i].setProperty(hmUI.prop.SRC, ROOTPATH + "weather/" + iconIndex + ".png");
					weekDay = (weekDay + 1)%7;
				}
			}

			let points = [];

			let maxTemp = Math.max(...tempH);
			let minTemp = Math.min(...tempL);
			let deltaX = 46;
			let x0 = 95 + deltaX/2; 		//начало x

			for (let i = 0; i < 6; i++) {
				let cX = x0 + deltaX * i - 5;
				let cY = 142 + ( maxTemp - tempH[i] ) * (120 / (maxTemp - minTemp));
				points.push({ x: cX, y: cY });			
				pointRed[i].setProperty(hmUI.prop.MORE, {
				  x: cX,
				  y: cY,
				  w: 10,
				  h: 10,
				  color: 0xFFFF0000,
				  radius: 10,
				});
			};

			for (let i = 1; i < 6; i++) {
				let l = Math.sqrt(Math.pow(points[i].x - points[i-1].x, 2) + Math.pow(points[i].y - points[i-1].y, 2));
				let nY = points[i-1].y + 2;
				let nAngle = Math.acos(deltaX / l) * 180 / Math.PI;
				
				if ((points[i].y - points[i-1].y) < 0){
					nAngle =  180 - nAngle;
					nY = points[i].y + 2;
				}
				
				lineRed[i-1].setProperty(hmUI.prop.MORE, {
				  x: points[i-1].x,
				  y: nY,
				  w: l + 11,
				  h: 4,
				  color: 0xFFFF0000,
				  radius: 4,
				  angle: nAngle,
				});
			}
			
			points = [];
			for (let i = 0; i < 6; i++) {
				let cX = x0 + deltaX/2 + deltaX * i - 5;
				let cY = 142 + ( maxTemp - tempL[i] ) * (120 / (maxTemp - minTemp));
				points.push({ x: cX, y: cY });				  
				pointBlue[i].setProperty(hmUI.prop.MORE, {
				  x: cX,
				  y: cY,
				  w: 10,
				  h: 10,
				  color: 0xFF00eaff,
				  radius: 10,
				});
			};

			for (let i = 1; i < 6; i++) {
			
				let l = Math.sqrt(Math.pow(points[i].x - points[i-1].x, 2) + Math.pow(points[i].y - points[i-1].y, 2));
				let nY = points[i-1].y + 2;
				let nAngle = Math.acos(deltaX / l) * 180 / Math.PI;
				
				if ((points[i].y - points[i-1].y) < 0){
					nAngle =  180 - nAngle;
					nY = points[i].y + 2;
				}
				
				lineBlue[i-1].setProperty(hmUI.prop.MORE, {
				  x: points[i-1].x,
				  y: nY,
				  w: l + 11,
				  h: 4,
				  color: 0xFF00EAFF,
				  radius: 4,
				  angle: nAngle,
				});
			}
			

			for (let i = 0; i < 6; i++) {
				tempHighText[i].setProperty(hmUI.prop.MORE, {
				  x: 96 - 5 + i * 45 * 1.02,
				  y: 142 + ( maxTemp - tempH[i] ) * (120 / (maxTemp - minTemp)) - 38,
				  w: 50,
				  h: 40,
				  color: "0xFFF0E68C",
				  text_size: 27,
				  text: tempH[i],
				  text_style: hmUI.text_style.NONE,
				  align_h: hmUI.align.CENTER_H,
				  align_v: hmUI.align.CENTER_V,
				});

				tempLowText[i].setProperty(hmUI.prop.MORE, {
				  x: 96 - 5 + 23 + i * 45 * 1.02,
				  y: 134 + ( maxTemp - tempL[i] ) * (120 / (maxTemp - minTemp)) + 8,
				  w: 50,
				  h: 40,
				  color: "0xFFE0FFFF",
				  text_size: 27,
				  text: tempL[i],
				  text_style: hmUI.text_style.NONE,
				  align_h: hmUI.align.CENTER_H,
				  align_v: hmUI.align.CENTER_V,
				});
			}
		}

		function showWeatherScreen() {
			drawWeatherGraph();
			weatherScreenOn = true;
			weatherScreen.setProperty(hmUI.prop.VISIBLE, true);
			hmSetting.setBrightScreen(closeWScreenTimeout);
			
			closeScreenTimeout = setTimeout(() => {
			  if(weatherScreenOn) hideWeatherScreen();
			}, closeWScreenTimeout);
        }


		function hideWeatherScreen() {
			weatherScreenOn = false;
			weatherScreen.setProperty(hmUI.prop.VISIBLE, false);
			hmSetting.setBrightScreenCancel();
			if(closeScreenTimeout) clearTimeout(closeScreenTimeout);
        }


        //vibrate (add destroy at end)
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let stopVibro_Timer = null;
		
		function vibro(scene = 25) {
			let stopDelay = 50;
			vibrate.stop();
			vibrate.scene = scene;
			if(scene < 23 || scene > 25) stopDelay = 1220;
			vibrate.start();
			stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
        }		

		function stopVibro(){
			vibrate.stop();
			timer.stopTimer(stopVibro_Timer);
		}

		function checkConnection() {
		  hmBle.removeListener;
		  hmBle.addListener(function (status) {
			if(!status) {
			  hmUI.showToast({text: "CONNECTION LOST!!!"});
			  vibro(27);
			}
		  });
		}
		
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0000bk.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 126,
              y: 20,
              src: 'status_clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 181,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
			  hour_unit_sc: 'colon_time.png',
              hour_unit_tc: 'colon_time.png',
              hour_unit_en: 'colon_time.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 175,
              minute_startY: 181,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
			  minute_unit_sc: 'colon_sec.png',
              minute_unit_tc: 'colon_sec.png',
              minute_unit_en: 'colon_sec.png',
              minute_align: hmUI.align.CENTER_H,
			  
			  second_startX: 308,
              second_startY: 181,
              second_array: ["sec_0.png","sec_1.png","sec_2.png","sec_3.png","sec_4.png","sec_5.png","sec_6.png","sec_7.png","sec_8.png","sec_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 424,
              font_array: ["0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 109,
              font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0047.png',
              unit_tc: '0047.png',
              unit_en: '0047.png',
              negative_image: '0046.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 59,
              font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0047.png',
              unit_tc: '0047.png',
              unit_en: '0047.png',
              negative_image: '0046.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 40,
              y: 94,
              font_array: ["t0011.png","t0012.png","t0013.png","t0014.png","t0015.png","t0016.png","t0017.png","t0018.png","t0019.png","t0020.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0047.png',
              unit_tc: '0047.png',
              unit_en: '0047.png',
              negative_image: 't0021.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 195,
              y: 79,
              image_array: ["wwwwwww00.png","wwwwwww01.png","wwwwwww02.png","wwwwwww03.png","wwwwwww04.png","wwwwwww05.png","wwwwwww06.png","wwwwwww07.png","wwwwwww08.png","wwwwwww09.png","wwwwwww10.png","wwwwwww11.png","wwwwwww12.png","wwwwwww13.png","wwwwwww14.png","wwwwwww15.png","wwwwwww16.png","wwwwwww17.png","wwwwwww18.png","wwwwwww19.png","wwwwwww20.png","wwwwwww21.png","wwwwwww22.png","wwwwwww23.png","wwwwwww24.png","wwwwwww25.png","wwwwwww26.png","wwwwwww27.png","wwwwwww28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 93,
              y: 306,
              week_en: ["0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              week_tc: ["0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              week_sc: ["0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 247,
              year_startY: 357,
              year_sc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              year_tc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              year_en_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 164,
              month_startY: 357,
              month_sc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              month_tc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              month_en_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 235,
              y: 392,
              src: '0101.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 79,
              day_startY: 357,
              day_sc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              day_tc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              day_en_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 152,
              y: 393,
              src: '0101.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            

			// открыть экран погоды 
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 87,
              text: '',
              w: 79,
              h: 68,
              normal_src: '0061.png',
              press_src: '0061.png',
              click_func: () => {
				vibro();
				showWeatherScreen(true);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 6,
              y: 166,
              w: 199,
              h: 120,
              src: '0061.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 259,
              y: 166,
              w: 199,
              h: 120,
              src: '0061.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 116,
              y: 0,
              w: 76,
              h: 78,
              src: '0061.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 290,
              y: 56,
              w: 144,
              h: 98,
              src: '0061.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			/*
            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 194,
              y: 87,
              w: 79,
              h: 68,
              src: '0061.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			*/

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 9,
              y: 92,
              w: 172,
              h: 63,
              src: '0061.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // КАЛЕНДАРЬ
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 77,
			  //x: 160,
              y: 303,
			  //y: 200,
              text: '',
              w: 311,
			  //w: 180,
              h: 103,
			  //h: 55,
              //src: '0061.png',
			  normal_src: '0061.png',
              press_src: '0061.png',
              click_func: () => {
				vibro();
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			
		/*    normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 77,
              y: 303,
              w: 311,
              h: 103,
              src: '0061.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
        */


		// --------------- экран погоды ------------- 
			weatherScreen = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
            });

            weatherScreen.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_weather.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            weatherScreen.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 309,
              y: 335,
              image_array: ["vl_prog_1.png","vl_prog_2.png","vl_prog_3.png","vl_prog_4.png","vl_prog_5.png","vl_prog_6.png","vl_prog_7.png","vl_prog_8.png","vl_prog_9.png","vl_prog_10.png"],
              image_length: 10,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            weatherScreen.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 99,
              y: 335,
              image_array: ["uv1.png","uv2.png","uv3.png","uv4.png","uv5.png"],
              image_length: 5,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            weatherScreen.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'arrow.png',
              center_x: 233,
              center_y: 233,
              x: 2,
              y: 233,
              start_angle: -2103, //-1670,
              end_angle: 404, //300,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			city_name_text = weatherScreen.createWidget(hmUI.widget.TEXT, {
			  x: 133,
			  y: 50 - 10,
			  w: 200,
			  h: 37,
			  text_size: 28,
			  char_space: 0,
			  line_space: 0,
			  color: 0xFFFFFFFF,
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V,
			  text_style: hmUI.text_style.NONE,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            weatherScreen.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 374,
              font_array: ["s_dig0.png","s_dig1.png","s_dig2.png","s_dig3.png","s_dig4.png","s_dig5.png","s_dig6.png","s_dig7.png","s_dig8.png","s_dig9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            weatherScreen.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'arrow_w.png',
              center_x: 233,
              center_y: 387,
              x: 7,
              y: 53,
              start_angle: -45,
              end_angle: 315,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			createGraphElements();

			// закрыть экран погоды
            weatherScreen.createWidget(hmUI.widget.BUTTON, {
              x: 365,
              y: 185,
              text: 'выход',
			  color: 0xEEF08080,
              w: 100,
              h: 120,
              normal_src: '0061.png',
              press_src: '0061.png',
              click_func: () => {
				hideWeatherScreen();
				vibro();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			hideWeatherScreen();
		// --------------- экран погоды ------------- \\


            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                stopVibro();
				if (weatherScreenOn) drawWeatherGraph();
				checkConnection();

              }),
              pause_call: (function () {
                stopVibro();
				hideWeatherScreen();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
				vibrate && vibrate.stop();
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
